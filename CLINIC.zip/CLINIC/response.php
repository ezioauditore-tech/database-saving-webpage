<?php
	
	$name= $_POST['name'];
	$Age= $_POST['age'];
    $gender= $_POST['gender'];
	$PhoneNumber= $_POST['phno'];
	$mailid=$_POST['mail'];
	$Info= $_POST['suggesstions'];
    $conn= new mysqli('localhost','root',"",'clinic1');
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    $values= "INSERT INTO Information(Name,Age,Gender,phno,mailid,info) VALUES('$name','$Age','$gender','$PhoneNumber','$mailid','$Info')";
    $conn->close();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Response</title>
	<link rel="stylesheet" type="text/css" href="response.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Reem+Kufi&display=swap" rel="stylesheet">
        <title> Ketamine clinic</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Aladin&family=Merienda+One&display=swap" rel="stylesheet">
</head>
<body>
    <div class="menubar">
		<img src="img/logo.png">
		<h1>Ketamine clinic</h1>
	</div>
	<div class="response">
		<?php
            
			echo"Name:".($name)."<br>";
			echo"Age:".($Age)."<br>";
			echo"Gender:".($gender)."<br>";
			echo"PhoneNumber:".($PhoneNumber)."<br>";
			echo"Mailid:".($mailid)."<br>";
			echo"Info:".($Info)."<br>";
		?>
	</div>
</body>
</html>