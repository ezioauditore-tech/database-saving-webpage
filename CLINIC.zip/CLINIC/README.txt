>>Paste The clinic1 folder in :\xamp\htdocs
>>Paste The clinic1 folder in :\xamp\mysql\data
